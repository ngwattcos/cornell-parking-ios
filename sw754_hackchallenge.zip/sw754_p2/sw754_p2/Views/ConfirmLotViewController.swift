//
//  ConfirmLotViewController.swift
//  sw754_p2
//
//  Created by Scott Wang on 11/21/19.
//  Copyright © 2019 Scott Wang. All rights reserved.
//

import UIKit

class ConfirmLotViewController: UIViewController {
    
    var lot: Lot?
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
